let cartItems = [];

function addToCart(item) {
  cartItems.push(item);
  updateCart();
}

function updateCart() {
  let cartList = document.getElementById('cart-items');
  cartList.innerHTML = '';
  cartItems.forEach(function(item) {
    let listItem = document.createElement('li');
    listItem.textContent = item;
    cartList.appendChild(listItem);
  });
}

function checkout() {
  if (cartItems.length > 0) {
    alert('Thank you for your order!');
    cartItems = [];
    updateCart();
  } else {
    alert('Your cart is empty. Please add items to your cart before checking out.');
  }
}
